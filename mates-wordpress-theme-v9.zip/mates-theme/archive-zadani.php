<?php get_header(); ?>

<main class="archive-section">
    <div class="container">
        <h1 class="page-title">Aktuální zadání</h1>

        <?php
        $rocniky = get_terms(array('taxonomy' => 'rocnik', 'orderby' => 'name', 'order' => 'DESC'));
        $serie = get_terms(array('taxonomy' => 'serie', 'orderby' => 'name', 'order' => 'ASC'));
        $current_rocnik = isset($_GET['rocnik']) ? sanitize_text_field($_GET['rocnik']) : '';
        $current_serie = isset($_GET['serie']) ? sanitize_text_field($_GET['serie']) : '';
        ?>

        <form method="get" style="margin-bottom: 2rem;">
            <select name="rocnik" onchange="this.form.submit()" style="padding: 0.5rem; margin-right: 1rem; border: 1px solid #d1d5db; border-radius: 0.375rem;">
                <option value="">Všechny ročníky</option>
                <?php foreach ($rocniky as $r) : ?>
                    <option value="<?php echo esc_attr($r->slug); ?>" <?php selected($current_rocnik, $r->slug); ?>><?php echo esc_html($r->name); ?></option>
                <?php endforeach; ?>
            </select>

            <select name="serie" onchange="this.form.submit()" style="padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.375rem;">
                <option value="">Všechny série</option>
                <?php foreach ($serie as $s) : ?>
                    <option value="<?php echo esc_attr($s->slug); ?>" <?php selected($current_serie, $s->slug); ?>><?php echo esc_html($s->name); ?></option>
                <?php endforeach; ?>
            </select>
        </form>

        <div class="assignments-list">
            <?php
            $query = mates_get_zadani($current_rocnik, $current_serie);

            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post();
                    $pdf = get_post_meta(get_the_ID(), '_mates_pdf', true);
                    $deadline = get_post_meta(get_the_ID(), '_mates_deadline', true);
                    $post_rocniky = get_the_terms(get_the_ID(), 'rocnik');
                    $post_serie = get_the_terms(get_the_ID(), 'serie');
            ?>
                <article class="assignment-card">
                    <div class="assignment-header">
                        <h2 class="assignment-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                    </div>

                    <div class="assignment-meta">
                        <?php if ($post_rocniky && !is_wp_error($post_rocniky)) : ?>
                            <span>Ročník: <?php echo esc_html($post_rocniky[0]->name); ?></span>
                        <?php endif; ?>

                        <?php if ($post_serie && !is_wp_error($post_serie)) : ?>
                            <span>Série: <?php echo esc_html($post_serie[0]->name); ?></span>
                        <?php endif; ?>

                        <?php if ($deadline) : ?>
                            <span>Termín: <?php echo esc_html(date('d.m.Y', strtotime($deadline))); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="assignment-excerpt">
                        <?php echo wp_trim_words(get_the_content(), 40); ?>
                    </div>

                    <?php if ($pdf) : ?>
                        <a href="<?php echo esc_url($pdf); ?>" target="_blank" class="pdf-button">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                            Stáhnout PDF
                        </a>
                    <?php endif; ?>
                </article>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
                <p style="text-align: center; color: #6b7280; padding: 3rem;">Zatím zde nejsou žádná zadání.</p>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
