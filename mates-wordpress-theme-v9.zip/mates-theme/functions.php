<?php
/**
 * MATES Theme Functions
 */

if (!defined('ABSPATH')) {
    exit;
}

// Načíst styly
function mates_scripts() {
    wp_enqueue_style('mates-style', get_stylesheet_uri(), array(), '1.0');
}
add_action('wp_enqueue_scripts', 'mates_scripts');

// Registrace menu
function mates_menus() {
    register_nav_menus(array(
        'primary' => __('Hlavní menu', 'mates'),
    ));
}
add_action('init', 'mates_menus');

// Custom Post Type: Zadání
function mates_register_post_types() {
    $labels_zadani = array(
        'name'                  => 'Zadání',
        'singular_name'         => 'Zadání',
        'menu_name'             => 'Zadání',
        'add_new'               => 'Přidat nové',
        'add_new_item'          => 'Přidat nové zadání',
        'edit_item'             => 'Upravit zadání',
        'new_item'              => 'Nové zadání',
        'view_item'             => 'Zobrazit zadání',
        'search_items'          => 'Hledat zadání',
    );

    register_post_type('zadani', array(
        'labels'                => $labels_zadani,
        'public'                => true,
        'has_archive'           => true,
        'menu_icon'             => 'dashicons-media-document',
        'supports'              => array('title', 'editor', 'thumbnail'),
        'taxonomies'            => array('rocnik', 'serie'),
        'rewrite'               => array('slug' => 'zadani'),
    ));

    // Komentáře/Zprávy
    $labels_zpravy = array(
        'name'                  => 'Zprávy',
        'singular_name'         => 'Zpráva',
        'menu_name'             => 'Zprávy',
        'add_new'               => 'Přidat novou',
        'add_new_item'          => 'Přidat novou zprávu',
        'edit_item'             => 'Upravit zprávu',
        'new_item'              => 'Nová zpráva',
        'view_item'             => 'Zobrazit zprávu',
    );

    register_post_type('zpravy', array(
        'labels'                => $labels_zpravy,
        'public'                => true,
        'has_archive'           => false,
        'menu_icon'             => 'dashicons-format-chat',
        'supports'              => array('title', 'editor'),
        'rewrite'               => array('slug' => 'zpravy'),
    ));
}
add_action('init', 'mates_register_post_types');

// Taxonomie
function mates_register_taxonomies() {
    register_taxonomy('rocnik', 'zadani', array(
        'labels' => array(
            'name'          => 'Ročníky',
            'singular_name' => 'Ročník',
            'menu_name'     => 'Ročníky',
        ),
        'hierarchical'      => true,
        'public'            => true,
        'show_admin_column' => true,
    ));

    register_taxonomy('serie', 'zadani', array(
        'labels' => array(
            'name'          => 'Série',
            'singular_name' => 'Série',
            'menu_name'     => 'Série',
        ),
        'hierarchical'      => true,
        'public'            => true,
        'show_admin_column' => true,
    ));
}
add_action('init', 'mates_register_taxonomies');

// Změnit URL příspěvků na /aktuality/nazev-prispevku/
function mates_change_post_permalink() {
    global $wp_rewrite;
    $wp_rewrite->permalink_structure = '/aktuality/%postname%/';  
    $wp_rewrite->flush_rules();
}
add_action('init', 'mates_change_post_permalink', 1);

// Metabox pro PDF a termín odevzdání
function mates_add_meta_boxes() {
    add_meta_box('mates_details', 'Detaily zadání', 'mates_details_callback', 'zadani', 'side');
    add_meta_box('mates_help_zadani', 'Nápověda', 'mates_help_zadani_callback', 'zadani', 'side', 'high');
}
add_action('add_meta_boxes', 'mates_add_meta_boxes');

function mates_details_callback($post) {
    wp_nonce_field('mates_save_details', 'mates_details_nonce');
    $pdf_url = get_post_meta($post->ID, '_mates_pdf', true);
    $deadline = get_post_meta($post->ID, '_mates_deadline', true);
    ?>
    <p>
        <label><strong>PDF soubor:</strong></label><br>
        <input type="url" name="mates_pdf" value="<?php echo esc_url($pdf_url); ?>" style="width:100%; margin-top:5px;" placeholder="URL PDF souboru">
    </p>
    <p>
        <label><strong>Termín odevzdání:</strong></label><br>
        <input type="date" name="mates_deadline" value="<?php echo esc_attr($deadline); ?>" style="width:100%; margin-top:5px;">
    </p>
    <?php
}

function mates_help_zadani_callback() {
    echo '<div style="background:#fff3cd;border:1px solid #ffeaa7;padding:10px;border-radius:4px;">
        <strong>📋 Jak přidat zadání:</strong><br><br>
        1. <strong>Název:</strong> "1. série 2025/2026"<br>
        2. <strong>Obsah:</strong> Text úloh (nebo nech prázdné)<br>
        3. <strong>Ročníky:</strong> Vyber nebo vytvoř ročník<br>
        4. <strong>Série:</strong> Vyber číslo série<br>
        5. <strong>PDF:</strong> Vlož odkaz na PDF soubor<br>
        6. <strong>Termín:</strong> Vyber datum odevzdání<br><br>
        <em>Uživatelé uvidí toto zadání na stránce "Zadání"</em>
    </div>';
}

function mates_save_meta($post_id) {
    if (!isset($_POST['mates_details_nonce']) || !wp_verify_nonce($_POST['mates_details_nonce'], 'mates_save_details')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (isset($_POST['mates_pdf'])) {
        update_post_meta($post_id, '_mates_pdf', esc_url_raw($_POST['mates_pdf']));
    }

    if (isset($_POST['mates_deadline'])) {
        update_post_meta($post_id, '_mates_deadline', sanitize_text_field($_POST['mates_deadline']));
    }
}
add_action('save_post', 'mates_save_meta');

// Nápověda pro stránky
function mates_page_help_meta_box() {
    add_meta_box('mates_help_page', 'Nápověda k této stránce', 'mates_help_page_callback', 'page', 'side', 'high');
}
add_action('add_meta_boxes', 'mates_page_help_meta_box');

function mates_help_page_callback($post) {
    $help_text = '';

    switch ($post->post_name) {
        case 'o-soutezi':
            $help_text = '<strong>🏫 Stránka "O soutěži"</strong><br><br>
            Tento text se zobrazí na stránce "O soutěži".<br><br>
            <strong>Co sem napsat:</strong><br>
            • Historii soutěže<br>
            • Cíle projektu<br>
            • Kontaktní informace<br><br>
            <em>Kontakt se zobrazuje také v patičce všech stránek.</em>';
            break;
        case 'pravidla':
            $help_text = '<strong>📜 Stránka "Pravidla"</strong><br><br>
            Tento text se zobrazí na stránce "Pravidla".<br><br>
            <strong>Obsah je předvyplněn:</strong><br>
            • Kdo se může přihlásit<br>
            • Jak posílat řešení<br>
            • Bodování<br>
            • Pravidla soutěže<br><br>
            <em>Můžeš upravit podle potřeby.</em>';
            break;
        case 'komentare':
            $help_text = '<strong>💬 Stránka "Komentáře"</strong><br><br>
            Obsah této stránky se nezobrazuje — používá se speciální šablona.<br><br>
            <strong>Proč?</strong> Stránka automaticky zobrazuje:<br>
            • Formulář pro návštěvníky<br>
            • Seznam odeslaných zpráv<br><br>
            <em>Zprávy spravuješ v menu "Zprávy" vlevo.</em>';
            break;
        case 'uvod':
            $help_text = '<strong>🏠 Úvodní stránka</strong><br><br>
            Tento text se zobrazí v modrém boxu na úvodní stránce pod nadpisem.<br><br>
            <strong>Co sem napsat:</strong><br>
            • Krátký popis soutěže<br>
            • Pro koho je určena<br>
            • Jak funguje<br><br>
            <em>Zbytek stránky (tlačítka, karty) je automatický.</em>';
            break;
        default:
            $help_text = '<strong>📝 Obecná stránka</strong><br><br>
            Tento text se zobrazí na webu.<br><br>
            <strong>Tipy:</strong><br>
            • Používej nadpisy pro strukturu<br>
            • Přidávej obrázky pomocí tlačítka "Přidat média"<br>
            • Ulož koncept, když to chceš dodělat později';
    }

    echo '<div style="background:#d1ecf1;border:1px solid #bee5eb;padding:10px;border-radius:4px;">' . $help_text . '</div>';
}

// Nápověda pro taxonomie
function mates_taxonomy_help() {
    echo '<div class="notice notice-info" style="margin:20px 0;padding:10px;">
        <strong>🏷️ Správa kategorií:</strong><br><br>
        <strong>Ročníky:</strong> Např. "2024/2025", "2025/2026"<br>
        <strong>Série:</strong> Např. "1. série", "2. série", "3. série", "4. série"<br><br>
        <em>Každé zadání musí mít přiřazený ročník a sérii.</em>
    </div>';
}
add_action('rocnik_pre_add_form', 'mates_taxonomy_help');
add_action('serie_pre_add_form', 'mates_taxonomy_help');

// Dashboard widget
function mates_dashboard_widget() {
    wp_add_dashboard_widget(
        'mates_help_widget',
        'MATES - Nápověda',
        'mates_dashboard_help_content'
    );
}
add_action('wp_dashboard_setup', 'mates_dashboard_widget');

function mates_dashboard_help_content() {
    echo '
    <div style="padding:10px;">
        <h3>🚀 Rychlý start</h3>
        <p><strong>Nejčastější úkony:</strong></p>
        <ol>
            <li><a href="/wp-admin/edit.php?post_type=zadani">Přidat nové zadání</a> — přidej úlohy pro aktuální sérii</li>
            <li><a href="/wp-admin/edit.php?post_type=zpravy">Spravovat zprávy</a> — čti a maž komentáře návštěvníků</li>
            <li><a href="/wp-admin/edit.php?post_type=page">Upravit stránky</a> — změň texty "Úvod", "O soutěži", "Pravidla"</li>
        </ol>

        <hr style="margin:15px 0;">

        <h3>📖 Struktura webu</h3>
        <ul>
            <li><strong>Úvod</strong> — hlavní stránka</li>
            <li><strong>Zadání</strong> — seznam všech úloh</li>
            <li><strong>Pravidla</strong> — jak soutěž funguje</li>
            <li><strong>Komentáře</strong> — formulář pro návštěvníky</li>
            <li><strong>O soutěži</strong> — kontakt a historie</li>
        </ul>

        <p style="color:#666;"><em>💡 URL příspěvků: /aktuality/nazev-prispevku/</em></p>
    </div>
    ';
}

// Získat aktuální ročník
function mates_get_current_rocnik() {
    $rocniky = get_terms(array(
        'taxonomy' => 'rocnik',
        'orderby' => 'name',
        'order' => 'DESC',
        'number' => 1,
    ));
    return !empty($rocniky) ? $rocniky[0] : null;
}

// Získat zadání
function mates_get_zadani($rocnik = '', $serie = '') {
    $args = array(
        'post_type' => 'zadani',
        'posts_per_page' => -1,
        'orderby' => 'date',
        'order' => 'DESC',
    );

    $tax_query = array();

    if ($rocnik) {
        $tax_query[] = array(
            'taxonomy' => 'rocnik',
            'field' => 'slug',
            'terms' => $rocnik,
        );
    }

    if ($serie) {
        $tax_query[] = array(
            'taxonomy' => 'serie',
            'field' => 'slug',
            'terms' => $serie,
        );
    }

    if (!empty($tax_query)) {
        $args['tax_query'] = $tax_query;
    }

    return new WP_Query($args);
}

// Zpracování formuláře zpráv
function mates_handle_message_form() {
    if (!isset($_POST['mates_message_submit'])) {
        return;
    }

    if (!wp_verify_nonce($_POST['mates_message_nonce'], 'mates_message_action')) {
        wp_die('Bezpečnostní kontrola selhala');
    }

    $name = sanitize_text_field($_POST['message_name']);
    $content = sanitize_textarea_field($_POST['message_content']);

    if (empty($name) || empty($content)) {
        wp_redirect(add_query_arg('message_status', 'error', wp_get_referer()));
        exit;
    }

    $post_id = wp_insert_post(array(
        'post_title'   => $name,
        'post_content' => $content,
        'post_type'    => 'zpravy',
        'post_status'  => 'publish',
    ));

    if ($post_id) {
        wp_redirect(add_query_arg('message_status', 'success', wp_get_referer()));
    } else {
        wp_redirect(add_query_arg('message_status', 'error', wp_get_referer()));
    }
    exit;
}
add_action('template_redirect', 'mates_handle_message_form');

// Vytvořit stránky při aktivaci šablony
function mates_create_pages() {
    $pages = array(
        'uvod' => array(
            'title' => 'Úvod',
            'content' => '<p>Soutěž organizovaná studenty Gymnázia Polička. Řešení úloh zasílejte poštou nebo elektronicky. Každý ročník obsahuje čtyři série úloh různé obtížnosti.</p>',
        ),
        'o-soutezi' => array(
            'title' => 'O soutěži',
            'content' => '<h2>O projektu MATES</h2><p>MATES je matematická korespondenční soutěž pro žáky 6. a 7. tříd základních škol.</p><h3>Historie</h3><p>Soutěž vznikla před několika lety jako studentský projekt Gymnázia Polička.</p><h3>Kontakt</h3><p><strong>Anežka Zahradníčková</strong><br>Tel: 731 073 582<br>Email: matesgympol@gmail.com</p>',
        ),
        'komentare' => array(
            'title' => 'Komentáře',
            'content' => '',
        ),
        'pravidla' => array(
            'title' => 'Pravidla a pokyny',
            'content' => '<h2>Pravidla a pokyny</h2>
<p>Do soutěže se můžeš přihlásit, pokud jsi žákem 6., 7. třídy nebo studentem odpovídajících ročníků nižšího gymnázia.</p>
<p>Příklady posílejte email <strong>mates@gympolicka.cz</strong> ve formě fotografie (zaostřená, na výšku) nebo jako dokument ve Wordu či jiném programu. Uveďte do emailu své jméno, třídu a školu. Neoznačená řešení nebudou započítávána do výsledků.</p>
<p>Za každou správně vyřešenou úlohu získáš 5 bodů. Za menší chyby a neúplné řešení strháváme body. Hodnotí se i kvalita postupu.</p>
<p><strong>Neopisuj!</strong> Soutěžíš přece sám za sebe.</p>
<p>Spolu s řešením 1. série vyplň na webu online přihlášku.</p>
<p>Řešení piš čitelně a srozumitelně, nezapomeň na postup !!!</p>
<p>Můžeš psát i dotazy a připomínky (zde na webu nebo na email mates@gympolicka.cz), které ti rádi zodpovíme.</p>
<p>Každý papír nebo dokument v levém horním rohu podepiš následovně:</p>',
        ),
    );

    foreach ($pages as $slug => $page_data) {
        $existing = get_page_by_path($slug);
        if (!$existing) {
            wp_insert_post(array(
                'post_title'   => $page_data['title'],
                'post_content' => $page_data['content'],
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_name'    => $slug,
            ));
        }
    }

    // Nastavit úvodní stránku
    $uvod = get_page_by_path('uvod');
    if ($uvod) {
        update_option('page_on_front', $uvod->ID);
        update_option('show_on_front', 'page');
    }
}
add_action('after_switch_theme', 'mates_create_pages');

// Při aktivaci šablony
function mates_activation() {
    mates_create_pages();
    // Nastavit strukturu permalinků
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure('/aktuality/%postname%/');
    $wp_rewrite->flush_rules();
}
add_action('after_switch_theme', 'mates_activation');
