<?php get_header(); ?>

<main class="content-section">
    <div class="container">
        <?php while (have_posts()) : the_post(); ?>
            <?php
            $pdf = get_post_meta(get_the_ID(), '_mates_pdf', true);
            $deadline = get_post_meta(get_the_ID(), '_mates_deadline', true);
            $post_rocniky = get_the_terms(get_the_ID(), 'rocnik');
            $post_serie = get_the_terms(get_the_ID(), 'serie');
            ?>

            <h1 class="page-title"><?php the_title(); ?></h1>

            <div class="assignment-meta" style="margin-bottom: 2rem;">
                <?php if ($post_rocniky && !is_wp_error($post_rocniky)) : ?>
                    <span>Ročník: <?php echo esc_html($post_rocniky[0]->name); ?></span>
                <?php endif; ?>

                <?php if ($post_serie && !is_wp_error($post_serie)) : ?>
                    <span>Série: <?php echo esc_html($post_serie[0]->name); ?></span>
                <?php endif; ?>

                <?php if ($deadline) : ?>
                    <span>Termín odevzdání: <?php echo esc_html(date('d.m.Y', strtotime($deadline))); ?></span>
                <?php endif; ?>
            </div>

            <?php if ($pdf) : ?>
                <div style="margin-bottom: 2rem;">
                    <a href="<?php echo esc_url($pdf); ?>" target="_blank" class="btn btn-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                        Stáhnout zadání (PDF)
                    </a>
                </div>
            <?php endif; ?>

            <div class="content-text">
                <?php the_content(); ?>
            </div>

            <div style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid #e5e7eb;">
                <a href="<?php echo get_post_type_archive_link('zadani'); ?>" class="btn btn-secondary">← Zpět na všechna zadání</a>
            </div>
        <?php endwhile; ?>
    </div>
</main>

<?php get_footer(); ?>
