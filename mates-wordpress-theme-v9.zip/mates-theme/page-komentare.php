<?php
/**
 * Template Name: Komentáře
 */
get_header();

$status = isset($_GET['message_status']) ? sanitize_text_field($_GET['message_status']) : '';
?>

<main class="comments-section">
    <div class="container">
        <h1 class="page-title">Komentáře a dotazy</h1>

        <p class="content-text">
            Máte dotaz k soutěži nebo konkrétní úloze? Napište nám. Odpovíme vám co nejdříve.
        </p>

        <!-- Seznam zpráv -->
        <div class="comments-list">
            <?php
            $zpravy = new WP_Query(array(
                'post_type' => 'zpravy',
                'posts_per_page' => 50,
                'orderby' => 'date',
                'order' => 'DESC',
            ));

            if ($zpravy->have_posts()) :
                while ($zpravy->have_posts()) : $zpravy->the_post();
            ?>
                <div class="comment-item">
                    <div class="comment-header">
                        <span class="comment-author"><?php the_title(); ?></span>
                        <span class="comment-date"><?php echo get_the_date('d.m.Y H:i'); ?></span>
                    </div>
                    <div class="comment-text">
                        <?php the_content(); ?>
                    </div>
                </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
                <p style="text-align: center; color: #6b7280; padding: 2rem;">Zatím zde nejsou žádné zprávy. Buďte první!</p>
            <?php endif; ?>
        </div>

        <!-- Formulář -->
        <div class="comment-form">
            <h3 class="form-title">Napsat zprávu</h3>

            <?php if ($status === 'success') : ?>
                <div class="form-message success">Děkujeme! Vaše zpráva byla odeslána.</div>
            <?php elseif ($status === 'error') : ?>
                <div class="form-message error">Chyba: Vyplňte prosím všechna pole.</div>
            <?php endif; ?>

            <form method="post" action="">
                <?php wp_nonce_field('mates_message_action', 'mates_message_nonce'); ?>

                <div class="form-group">
                    <label class="form-label" for="message_name">Jméno</label>
                    <input type="text" id="message_name" name="message_name" class="form-input" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="message_content">Zpráva</label>
                    <textarea id="message_content" name="message_content" class="form-textarea" required></textarea>
                </div>

                <button type="submit" name="mates_message_submit" class="form-submit">Odeslat zprávu</button>
            </form>
        </div>
    </div>
</main>

<?php get_footer(); ?>
