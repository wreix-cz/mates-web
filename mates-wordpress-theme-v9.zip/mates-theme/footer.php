    <footer class="site-footer">
        <div class="container">
            <div class="footer-inner">
                <div>
                    <a href="<?php echo home_url('/'); ?>" class="footer-logo">MATES</a>
                    <p class="footer-text">Matematická korespondenční soutěž</p>
                </div>

                <div style="text-align: center;">
                    <div class="footer-contact" style="margin-bottom: 0.5rem;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                        <a href="mailto:matesgympol@gmail.com">matesgympol@gmail.com</a>
                    </div>
                    <div class="footer-contact">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        <span>Anežka Zahradníčková | Tel. 731 073 582</span>
                    </div>
                </div>

                <div class="footer-text">
                    Organizuje: Gymnázium Polička<br>
                    © <?php echo date('Y'); ?> MATES
                </div>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
</body>
</html>
