<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header class="site-header">
        <div class="container">
            <div class="header-inner">
                <a href="<?php echo home_url('/'); ?>" class="site-logo">MATES</a>

                <nav class="main-nav">
                    <ul>
                        <li><a href="<?php echo home_url('/'); ?>" <?php echo is_front_page() ? 'class="active"' : ''; ?>>Úvod</a></li>
                        <li><a href="<?php echo get_post_type_archive_link('zadani'); ?>" <?php echo is_post_type_archive('zadani') ? 'class="active"' : ''; ?>>Zadání</a></li>
                        <li><a href="<?php echo get_permalink(get_page_by_path('pravidla')); ?>" <?php echo is_page('pravidla') ? 'class="active"' : ''; ?>>Pravidla</a></li>
                        <li><a href="<?php echo get_permalink(get_page_by_path('komentare')); ?>" <?php echo is_page('komentare') ? 'class="active"' : ''; ?>>Komentáře</a></li>
                        <li><a href="<?php echo get_permalink(get_page_by_path('o-soutezi')); ?>" <?php echo is_page('o-soutezi') ? 'class="active"' : ''; ?>>O soutěži</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
