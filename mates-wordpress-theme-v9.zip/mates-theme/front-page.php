<?php
/**
 * Template Name: Úvodní stránka
 */
get_header();
?>

<main>
    <section class="hero">
        <div class="container">
            <h1 class="hero-logo">MATES</h1>
            <h2 class="hero-title">Matematická korespondenční soutěž</h2>
            <p class="hero-subtitle">Pro žáky 6. a 7. tříd základních škol</p>

            <?php 
            // Načti obsah z úvodní stránky
            $uvodni_stranka = get_page_by_path('uvod');
            if ($uvodni_stranka) : 
                echo '<div class="hero-description">';
                echo apply_filters('the_content', $uvodni_stranka->post_content);
                echo '</div>';
            else : 
            ?>
            <p class="hero-description">
                Soutěž organizovaná studenty Gymnázia Polička. Řešení úloh zasílejte poštou nebo elektronicky. 
                Každý ročník obsahuje čtyři série úloh různé obtížnosti.
            </p>
            <?php endif; ?>

            <div class="button-group">
                <a href="<?php echo get_post_type_archive_link('zadani'); ?>" class="btn btn-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    Aktuální zadání
                </a>
                <a href="<?php echo get_post_type_archive_link('zadani'); ?>" class="btn btn-secondary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
                    Archiv
                </a>
                <a href="<?php echo get_permalink(get_page_by_path('pravidla')); ?>" class="btn btn-secondary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    Pravidla
                </a>
            </div>
        </div>
    </section>

    <!-- Aktuality - zarovnané od středu -->
    <?php
    $aktualni_prispevky = new WP_Query(array(
        'post_type' => 'post',
        'posts_per_page' => 3,
    ));

    if ($aktualni_prispevky->have_posts()) :
    ?>
    <section class="news-section" style="padding: 2rem 1rem; background: #ffffff; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb;">
        <div class="container">
            <h3 class="section-title">Aktuality</h3>
            <div class="news-grid" style="display: flex; justify-content: center; gap: 1.5rem; flex-wrap: wrap; max-width: 1000px; margin: 0 auto;">
                <?php while ($aktualni_prispevky->have_posts()) : $aktualni_prispevky->the_post(); ?>
                <div class="news-card" style="background: #f9fafb; padding: 1.5rem; border-radius: 0.5rem; border: 1px solid #e5e7eb; width: 300px; text-align: center;">
                    <h4 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.5rem; color: #111827;"><?php the_title(); ?></h4>
                    <p style="color: #6b7280; font-size: 0.875rem; margin-bottom: 1rem;"><?php echo wp_trim_words(get_the_content(), 15); ?></p>
                    <a href="<?php the_permalink(); ?>" style="color: #2563eb; font-size: 0.875rem; text-decoration: none;">Číst více →</a>
                </div>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <section class="features-section">
        <div class="container">
            <div class="features-grid">
                <div class="feature-card">
                    <svg class="feature-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg>
                    <h3 class="feature-title">Čtyři série ročně</h3>
                    <p class="feature-text">Každý ročník obsahuje čtyři série úloh s různou obtížností pro 6. a 7. třídu. Řešení odevzdávejte vždy do uvedeného termínu.</p>
                </div>

                <div class="feature-card">
                    <svg class="feature-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                    <h3 class="feature-title">Organizují studenti</h3>
                    <p class="feature-text">Soutěž vznikla a funguje pod záštitou studentů Gymnázia Polička. Úlohy tvoří a hodnotí sami studenti.</p>
                </div>

                <div class="feature-card">
                    <svg class="feature-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
                    <h3 class="feature-title">Komentáře a dotazy</h3>
                    <p class="feature-text">Máte dotaz k úloze nebo soutěži? Napište nám prostřednictvím jednoduchého formuláře bez nutnosti registrace.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="quick-links-section">
        <div class="container">
            <h3 class="section-title">Rychlé odkazy</h3>
            <div class="quick-links-grid">
                <a href="<?php echo get_post_type_archive_link('zadani'); ?>" class="quick-link-card">
                    <svg class="quick-link-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    <div class="quick-link-content">
                        <h4>Aktuální zadání</h4>
                        <p>Stáhněte si aktuální sérii úloh</p>
                    </div>
                </a>

                <a href="<?php echo get_post_type_archive_link('zadani'); ?>" class="quick-link-card">
                    <svg class="quick-link-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
                    <div class="quick-link-content">
                        <h4>Archiv</h4>
                        <p>Zadání a výsledky předchozích ročníků</p>
                    </div>
                </a>

                <a href="<?php echo get_permalink(get_page_by_path('pravidla')); ?>" class="quick-link-card">
                    <svg class="quick-link-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    <div class="quick-link-content">
                        <h4>Pravidla a pokyny</h4>
                        <p>Jak se zúčastnit a bodování</p>
                    </div>
                </a>

                <a href="<?php echo get_permalink(get_page_by_path('komentare')); ?>" class="quick-link-card">
                    <svg class="quick-link-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
                    <div class="quick-link-content">
                        <h4>Komentáře</h4>
                        <p>Napište nám zprávu nebo dotaz</p>
                    </div>
                </a>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
